﻿#pragma once
#include<string>
#include<sstream>
#include<vector>


namespace Debug {
	inline std::vector<std::string>& GetLogs() {
		static std::vector<std::string> logs;
		return logs;
	}

	template<class T>
	static void Log(const T& log) {
		std::ostringstream stream;
		stream << log;

		GetLogs().push_back(stream.str());

		//最新20件だけ残す
		auto& logs = GetLogs();

		if (logs.size() > 20) {
			logs.erase(logs.begin());
		}
	}

	inline void ClearLog() {
		GetLogs().clear();
	}
}