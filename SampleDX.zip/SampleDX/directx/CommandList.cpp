﻿#include "CommandList.h"
#include<cassert>

CommandList::~CommandList()
{
	if (commandList_) {
		commandList_->Release();
		commandList_ = nullptr;
	}
}

[[nodiscard]] bool CommandList::create(const CommandAllocator & commandAllocator) noexcept
{
	//コマンドリストの作成
	const auto hr = Device::instance().get()->CreateCommandList(0, commandAllocator.getType(), commandAllocator.get(), nullptr, IID_PPV_ARGS(&commandList_));
	if (FAILED(hr))
	{
		assert(false && "コマンドリストの作成に失敗\0");
		return false;
	}

	//コマンドリストを初期化状態に設定
	commandList_->Close();
	return true;
}

void CommandList::reset(const CommandAllocator& commandAllocator) noexcept
{
	if (!commandList_) {
		assert(false && "コマンドリストが未作成です\0");
	}

	//コマンドリストをリセット
	commandList_->Reset(commandAllocator.get(), nullptr);
}

[[nodiscard]] ID3D12GraphicsCommandList* CommandList::get() const noexcept
{
	if (!commandList_) {
		assert(false && "コマンドリストが未作成です\0");
		return nullptr;
	}
	return commandList_;
}


