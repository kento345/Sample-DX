﻿#pragma once
#include<d3d12.h>
#include<DirectXMath.h>
#include<wrl/client.h>

#include<string_view>
#include<vector>
#include<cstdint>
#include<memory>

#include"../directx/PiplineStateObject.h"
#include"../window/Window_Base.h"
#include"../MoveProhibited/Nomove.h"

class TextRender final : public Nomove
{
public:
	TextRender() = default;
	~TextRender() = default;

	[[nodiscard]] bool Initialize(const PiplineStateObject& piplineInstance, const std::unique_ptr<Window_Base>& window) noexcept;

	void TextDraw(const std::wstring_view text, const float x,const float y,const float fontSize, const DirectX::XMFLOAT4& color)noexcept;

private:
	struct Vertex
	{
		DirectX::XMFLOAT3 position;
		DirectX::XMFLOAT4 color;
	};

	void CreateTextVertices(
		const std::string_view text,
		const float x,
		const float y,
		const float fontSize,
		const DirectX::XMFLOAT4& color
	);
	// 各文字のビットマップを取得
	bool GetGlyph(
		char character,
		uint8_t rows[7]
	) const;

	// 1文字分の四角形を頂点に変換
	void AddGlyph(
		const char character,
		const float x,
		const float y,
		const float fontSize,
		const DirectX::XMFLOAT4& color
	);

private	:
	std::vector<Vertex> vertices;
	Microsoft::WRL::ComPtr<ID3D12Resource> vertexBuffer;
	D3D12_VERTEX_BUFFER_VIEW vertexBufferView_{}; //頂点バッファビュー
	std::unique_ptr<Vertex> mappedVertices;
	UINT vertexCapcity = 0;
};