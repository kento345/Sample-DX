﻿#include<Windows.h>
#include<cassert>

#include "Application.h"

#include"../../directx/Device.h"
#include"../../object/GameObjectManager.h"

#include"../../window/FullWindow.h"
#include"../../window/ScaleWindow.h"

namespace {
	constexpr UINT sceneShaderSlot_ = 0; //シーン共通シェーダースロット
}


bool a = true;

/// <summary>
/// 初期化
/// </summary>
/// <returns></returns>
bool Application::initialize(HINSTANCE hInstance)
{
	//フルスクリーンウィンドウの生成
	if (a) {
		auto wi = std::make_unique<FullWindow>();
		if (S_OK != wi->create(hInstance, L"SampleDX"))
		{
			assert(false && "ウィンドウの作成に失敗しました");
			return false;
		}
		windowInstance_ = std::move(wi);
	}
	//サイズ変更可ウィンドウの生成
	else {
		auto wi = std::make_unique<ScaleWindow>();

		if (S_OK != wi->create(hInstance, 1280, 720, L"SampleDX"))
		{
			assert(false && "ウィンドウの作成に失敗しました");
			return false;
		}
		windowInstance_ = std::move(wi);
	}

	//デバイスの生成
	if (!Device::instance().create()) {
		assert(false && "デバイスの作成に失敗しました");
		return false;
	}

	//コマンドキューの生成
	if (!commandQueueInstance_.create()) {
		assert(false && "コマンドキューの作成に失敗しました");
		return false;
	}

	//スワップチェインの生成
	if (!swapChainInstance_.create(windowInstance_, commandQueueInstance_)) {
		assert(false && "スワップチェインの作成に失敗しました");
		return false;
	}

	//ディスクリプタヒープの生成
	if (!DescriptorHeapContainer::instance().create(D3D12_DESCRIPTOR_HEAP_TYPE_RTV, swapChainInstance_.getDesc().BufferCount)) {
		assert(false && "ディスクリプタヒープの作成に失敗しました");
		return false;
	}

	//定数バッファ用ディスクリプタヒープの作成
	if (!DescriptorHeapContainer::instance().create(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV, 64, true)) {
		assert(false && "定数バッファ用ディスクリプタヒープの作成に失敗しました");
		return false;
	}

	//デプスバッファ用ディスクリプタヒープの作成
	if (!DescriptorHeapContainer::instance().create(D3D12_DESCRIPTOR_HEAP_TYPE_DSV, 1)) {
		assert(false && "デプスバッファ用ディスクリプタヒープの作成に失敗しました");
		return false;
	}

	//レンダーターゲットの生成
	if (!renderTargetInstance_.createBackBuffer(swapChainInstance_)) {
		assert(false && "レンダーターゲットの作成に失敗しました");
		return false;
	}

	// デプスバッファの生成
	if (!depthBufferInstance_.create(windowInstance_)) {
		assert(false && "デプスバッファの作成に失敗しました");
		return false;
	}

	//コマンドアロケータの生成
	if (!commandAllocatorInstance_[0].create(D3D12_COMMAND_LIST_TYPE_DIRECT)) {
		assert(false && "コマンドアロケータの作成に失敗しました");
		return false;
	}

	if (!commandAllocatorInstance_[1].create(D3D12_COMMAND_LIST_TYPE_DIRECT)) {
		assert(false && "コマンドアロケータの作成に失敗しました");
		return false;
	}

	//コマンドリストの生成
	if (!commandListInstance_.create(commandAllocatorInstance_[0])) {
		assert(false && "コマンドリストの作成に失敗しました");
		return false;
	}

	//フェンスの生成
	if (!fenceInstance_.create()) {
		assert(false && "フェンスの作成に失敗しました");
		return false;
	}

	//ルートシグネチャの生成
	if (!rootSignatureInstance_.create()) {
		assert(false && "ルートシグネチャの作成に失敗しました");
		return false;
	}
	//シェーダの生成
	if (!shaderInstance_.create()) {
		assert(false && "シェーダーの作成に失敗しました");
		return false;
	}
	//パイプラインステートオブジェクトの生成
	if (!piplineStateObjectInstance_.create(shaderInstance_, rootSignatureInstance_)) {
		assert(false && "パイプラインステートオブジェクトの作成に失敗しました");
		return false;
	}
	
	//カメラの生成
	camera_ = std::make_unique<game::Camera>();
	camera_->initialize();

	game::GameObjectManager::instance().createObject<game::Player>();
	game::GameObjectManager::instance().createObject<game::Enemy>();

    return true;
}

/// <summary>
 /// リソースバリアを設定
 /// </summary>
 /// <param name="resource"></param>
 /// <param name="from"></param>
 /// <param name="to"></param>
 /// <returns></returns>
D3D12_RESOURCE_BARRIER resourceBarrier(ID3D12Resource* resource, D3D12_RESOURCE_STATES from, D3D12_RESOURCE_STATES to) noexcept {
	D3D12_RESOURCE_BARRIER barrier{};
	barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
	barrier.Flags = D3D12_RESOURCE_BARRIER_FLAG_NONE;
	barrier.Transition.pResource = resource;
	barrier.Transition.StateBefore = from;
	barrier.Transition.StateAfter = to;
	barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;

	return barrier;
}

void Application::loop() noexcept
{
	while (windowInstance_->messageLoop())
	{
		// カメラの更新
		camera_->update();

		// ゲームオブジェクトの更新
		game::GameObjectManager::instance().update();

		// ゲームオブジェクトの後更新
		game::GameObjectManager::instance().postUpdate();


		// 描画処理 /////////////////////////////////////////////////////////////////////////

		// 現在のバックバッファインデックスを取得
		const auto backBufferIndex = swapChainInstance_.get()->GetCurrentBackBufferIndex();

		// 以前のフレームの GPU の処理が完了しているか確認して待機する
		if (frameFenceValue_[backBufferIndex] != 0) {
			fenceInstance_.wait(frameFenceValue_[backBufferIndex]);
		}

		// ディスクリプタヒープの解放予約分を解放
		DescriptorHeapContainer::instance().applyPendingFree();

		// コマンドアロケータリセット
		commandAllocatorInstance_[backBufferIndex].reset();
		// コマンドリストリセット
		commandListInstance_.reset(commandAllocatorInstance_[backBufferIndex]);

		// リソースバリアでレンダーターゲットを Present から RenderTarget へ変更
		auto pToRT = resourceBarrier(renderTargetInstance_.get(backBufferIndex), D3D12_RESOURCE_STATE_PRESENT, D3D12_RESOURCE_STATE_RENDER_TARGET);
		commandListInstance_.get()->ResourceBarrier(1, &pToRT);

		// レンダーターゲットの設定
		D3D12_CPU_DESCRIPTOR_HANDLE handles[] = { renderTargetInstance_.getDescriptorHandle(backBufferIndex) };
		// デプスバッファのハンドルも設定
		D3D12_CPU_DESCRIPTOR_HANDLE depthHandle = depthBufferInstance_.getCpuDescriptorHandle();
		commandListInstance_.get()->OMSetRenderTargets(1, handles, false, &depthHandle);

		// レンダーターゲットのクリア
		const float clearColor[] = { 0.2f, 0.2f, 0.2f, 1.0f };  // クリア
		commandListInstance_.get()->ClearRenderTargetView(handles[0], clearColor, 0, nullptr);
		// デプスバッファのクリア
		commandListInstance_.get()->ClearDepthStencilView(depthHandle, D3D12_CLEAR_FLAG_DEPTH, 1.0f, 0, 0, nullptr);

		// ルートシグネチャの設定
		commandListInstance_.get()->SetGraphicsRootSignature(rootSignatureInstance_.get());

		// ビューポートの設定
		const auto [w, h] = windowInstance_->size();
		D3D12_VIEWPORT viewport{};
		viewport.TopLeftX = 0.0f;
		viewport.TopLeftY = 0.0f;
		viewport.Width = static_cast<float>(w);
		viewport.Height = static_cast<float>(h);
		viewport.MinDepth = 0.0f;
		viewport.MaxDepth = 1.0f;
		commandListInstance_.get()->RSSetViewports(1, &viewport);

		// シザー矩形の設定
		D3D12_RECT scissorRect{};
		scissorRect.left = 0;
		scissorRect.top = 0;
		scissorRect.right = w;
		scissorRect.bottom = h;
		commandListInstance_.get()->RSSetScissorRects(1, &scissorRect);

		// コンスタントバッファ用ディスクリプタヒープの設定
		ID3D12DescriptorHeap* p[] = { DescriptorHeapContainer::instance().get(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV) };
		commandListInstance_.get()->SetDescriptorHeaps(1, p);

		// パイプラインステートの設定
		commandListInstance_.get()->SetPipelineState(piplineStateObjectInstance_.get());

		// カメラのコンスタントバッファへデータ転送
		camera_->updateDrawBuffer();
		camera_->setDrawCommand(commandListInstance_, sceneShaderSlot_);

		// ゲームオブジェクトの描画
		game::GameObjectManager::instance().draw(commandListInstance_);

		//-------------------------------------------------

		// リソースバリアでレンダーターゲットを RenderTarget から Present へ変更
		auto rtToP = resourceBarrier(renderTargetInstance_.get(backBufferIndex), D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_PRESENT);
		commandListInstance_.get()->ResourceBarrier(1, &rtToP);

		// コマンドリストをクローズ
		commandListInstance_.get()->Close();

		// コマンドキューにコマンドリストを送信
		ID3D12CommandList* ppCommandLists[] = { commandListInstance_.get() };
		commandQueueInstance_.get()->ExecuteCommandLists(_countof(ppCommandLists), ppCommandLists);

		// プレゼント
		swapChainInstance_.get()->Present(1, 0);

		// フェンスにフェンス値を設定
		commandQueueInstance_.get()->Signal(fenceInstance_.get(), nextFenceValue_);
		frameFenceValue_[backBufferIndex] = nextFenceValue_;
		nextFenceValue_++;
	}

	commandQueueInstance_.get()->Signal(fenceInstance_.get(), nextFenceValue_);
	fenceInstance_.wait(nextFenceValue_);
	game::GameObjectManager::instance().clear();
}